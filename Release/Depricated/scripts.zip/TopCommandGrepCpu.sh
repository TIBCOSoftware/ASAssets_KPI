#!/bin/sh
top -b -n 4 | grep Cpu
exit 0
