#!/bin/sh
# Linux 6 command and format
free -m | grep '/cache'  
exit 0
