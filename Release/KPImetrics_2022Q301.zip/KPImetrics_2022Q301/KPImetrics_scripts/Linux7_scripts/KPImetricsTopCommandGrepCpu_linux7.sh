#!/bin/sh
# Linux 7 command and format
top -b -n 4 | grep Cpu | sed  -e '1,$s/ us/\%us/' \
-e '1,$s/ sy/\%sy/' \
-e '1,$s/ ni/\%ni/' \
-e '1,$s/ id/\%id/' \
-e '1,$s/ wa/\%wa/' \
-e '1,$s/ hi/\%hi/' \
-e '1,$s/ si/\%si/' \
-e '1,$s/ st/\%st/' \
-e '1,$s/^\%//'

exit 0
