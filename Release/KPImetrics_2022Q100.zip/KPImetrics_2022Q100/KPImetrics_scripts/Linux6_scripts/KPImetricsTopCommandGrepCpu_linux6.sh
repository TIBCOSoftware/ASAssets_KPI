#!/bin/sh
# Linux 6 command and format
top -b -n 4 | grep Cpu
exit 0
