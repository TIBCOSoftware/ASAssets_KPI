
Objective:
	Import the optional Oracle 19c or SQL Server 2019 data sources

-----------------------
NEW DATABASE TABLES
-----------------------
Instructions to create a new installation using Oracle 19c or SQL Server 2019 are as follows:

1.	Follow the normal configuration steps in the manual for a new installation

2.	After the step to import the KPImetrics car file, decide which optional data source is required and import it:
	a. For Oracle 19c:      Import the KPImetrics_2020Q401_TDV8.3_oracle_19c.car data source by importing into “Desktop (admin)”
	a. For SQL Server 2019: Import the KPImetrics_2020Q401_TDV8.3_sqlserver_2019.car data source by importing into “Desktop (admin)”

3.	Continue following the normal installation steps in the manul.


-----------------------
MIGRATE DATABASE TABLES
-----------------------
Instructions to migrate tables from an earlier version of the database are as follows:

1.	Turn off /policy/metrics

2.	Turn off the KPImetrics triggers
	a.	/shared/ASAssets/KPImetrics/Configuration/updateTriggers(0)
	
3.	Decide which data source is required:
	a. For Oracle 19c:      Import the KPImetrics_2020Q401_TDV8.3_oracle_19c.car data source by importing into “Desktop (admin)”
	a. For SQL Server 2019: Import the KPImetrics_2020Q401_TDV8.3_sqlserver_2019.car data source by importing into “Desktop (admin)”
	
4.	Update the capabilities file in the file system for each node of the server:
	a.  For Oracle
		Source: If migrating from an earlier Oracle version such as 12c, copy the 2 entries from your 12c adapter (oracle_12c_thin_driver_values.xml)
				TDV_HOME/conf/adapters/system/oracle_12c_thin_driver/oracle_12c_thin_driver_values.xml
		Target: TDV_HOME/conf/adapters/system/oracle_19c_thin_driver/oracle_19c_thin_driver_values.xml
	b.  For SQL Server
		Source: If migrating from an earlier SQL Server version such as 2016, copy the 2 entries from your 2016 adapter (microsoft_sql_server_2016_values.xml)
				TDV_HOME/conf/adapters/system/microsoft_sql_server_2016/microsoft_sql_server_2016_values.xml
		Target: TDV_HOME/conf/adapters/system/microsoft_sql_server_2019/microsoft_sql_server_2019_values.xml
	
5.	Restart each TDV node in the cluster

6.	Modify /shared/ASAssets/KPImetrics/customize/commonValues.dataSourceName to point to that data source

7.	For existing tables to be migrated
	a.	Have the DBA migrate your schema and tables from the earlier database version to the current one.
	b.	For Oracle:
		Introspect the KPI_oracle_19c datasource and bring in the same procedures and tables that you had in 12c or 10g
	c.	For SQL Server:
		Introspect the KPI_sqlserver_2019 datasource and bring in the same procedures and tables that you had in 2016
	d.	Execute /shared/ASAssets/KPImetrics/Configuration/rebindPhysicalDatabaseType
	
