README

The following patches are only for use by Tibco PSG consulting.
Customers should follow the normal upgrade process or re-install from scratch.

Tibco PSG