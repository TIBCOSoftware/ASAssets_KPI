Release items (compiled jar files, car files, pdf documents) should be placed here
