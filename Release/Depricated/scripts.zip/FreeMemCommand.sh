#!/bin/sh
free -m | grep '/cache'  
exit 0
